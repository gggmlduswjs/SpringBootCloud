package com.acorn.pageSample.ex;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Acorn {
    private String id;
    private String pw;
    private String email;


}
