package com.acorn.pageSample.ex;

import lombok.Data;

@Data
public class Handler {

    int start;
    int end;
}
