package com.example.day08Valid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day08ValidApplicationTests {

	@Test
	void contextLoads() {
	}

}
