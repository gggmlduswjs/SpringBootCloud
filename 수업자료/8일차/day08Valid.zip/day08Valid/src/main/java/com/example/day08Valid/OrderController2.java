package com.example.day08Valid;


import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Slf4j
@Controller
public class OrderController2 {
    
    
    //주문화면


    @GetMapping("/order-form2")
    //ublic  String orderForm( @ModelAttribute(name="order") Order order ){
    public  String orderForm( Model model ){
        Order order =new Order();
        model.addAttribute("order" , order);
        return "order-form2";
    }
     
    
    //주문처리
    //사용자가 폼에서 입력한 주문정보를 처리하기 
    //검증성공 ( home 으로 가기)
    //검증실패 (다시 입력폼으로 , BindingResult 객체 사용하기 -오류정보 담기(비즈니스 체크하기) )


    //검증 ( 비지니스에 맞는 검증)
    // 검증에 실패했을 때 bindingResult객체에 오류정보 저장하기
    // view에서 검증오류를 바로 th:errors로 사용가능함
    
    @PostMapping("/order2")
    public  String  order(@ModelAttribute(name ="order") Order order  , BindingResult bindingResult){

        

        log.info("order={}" , order);
        //검증하기
        //오류가 있으면 bindingResult에 오류 등록하기
        //상품이름을 입력안하면 에러발생
         // null , ''
        if( order.getName().isEmpty() ||  order.getName().isBlank()){
           //입력필수 오류

            //에러등록하는 방법(4개)
            //FieldError 직접 만들기
            //rjectValue 매서드는 내부적으로 FiledError 생성
            //bindingResult.rejectValue
            //        ("name" ,
            //                "required" ,   //error 코드 생성
            //                new Object[]{"제품"} ,  //에러코드에 대하 에러메시지에 argument전달
            //                "상품이름은 필수이다" );  //에러코드에 대한 에러메시지가 없는경우 기본메시지 제공


            //addError()매서드 사용해서 오류등록하기
            // new FieldError()생성하기
            //-기본메시지
            //-에러코드, 에러메시지

            //bindingResult.addError( new FieldError("order"  , "name" , "상품코드를 입력하시오  fieldError"));
           // bindingResult.addError(
            //        new FieldError
             //               ("order" ,
             //                       "name" ,
             //                       order.getName()
             //                       ,false ,
             //                       new String[]{"nameError" , "nameError.order.name"},
             //                       new Object[]{"item"} ,
             //                       "상품이름을 반드시 입력하시오"));



        //
            //bindingResult.rejectValue("name" , "required"  ,"상품코드 필수 !!");

           bindingResult.rejectValue
                    ("name" ,
                          "required" ,   //error 코드 생성
                           new Object[]{"제품"} ,  //에러코드에 대하 에러메시지에 argument전달
                          "상품이름은 필수이다" );  //에러코드에 대한 에러메시지가 없는경우 기본메시지 제공




            //가격검증하기  ( >=이상 이어야 한다)

            if( order.getPrice()  < 1000000){

                bindingResult.rejectValue("price",  "range"  , new Object[]{ "1000000"}  ,"기본메시지 : 1000000이어야 한다");
            }



            //수량검증하기 ( 1~9999)이어야 한다
            if(  order.getQty() <1  || order.getQty() >9999){
                bindingResult.rejectValue("qty" , "range2" , new Object[]{"1" , "9999"} ,"수량을 확인하시오");
            }

        }

        
       
        //검증하기
        //에러가 등록된것이 있으면
        if(bindingResult.hasErrors())  {
            //검증실패
            return  "order-form2";
             
        }else{
            //검증성공
            return  "redirect:/home";
        }


    }
}
