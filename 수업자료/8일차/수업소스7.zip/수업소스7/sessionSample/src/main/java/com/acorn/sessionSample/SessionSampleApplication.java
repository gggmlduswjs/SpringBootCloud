package com.acorn.sessionSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionSampleApplication.class, args);
	}

}
