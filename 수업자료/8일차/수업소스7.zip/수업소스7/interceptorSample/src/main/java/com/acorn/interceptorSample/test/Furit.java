package com.acorn.interceptorSample.test;

import org.springframework.stereotype.Component;


public class Furit {
}
