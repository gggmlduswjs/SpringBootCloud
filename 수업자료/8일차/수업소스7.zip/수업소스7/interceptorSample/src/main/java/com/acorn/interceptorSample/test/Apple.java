package com.acorn.interceptorSample.test;

import org.springframework.stereotype.Component;

@Component("apple")
public class Apple  extends Furit {
}
