package com.acorn.interceptorSample.test;

import org.springframework.stereotype.Component;

@Component("banana")
public class Banana extends  Furit {
}
