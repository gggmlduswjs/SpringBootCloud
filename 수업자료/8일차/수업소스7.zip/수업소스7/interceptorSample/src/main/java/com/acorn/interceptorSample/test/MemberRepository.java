package com.acorn.interceptorSample.test;

public class MemberRepository {

    public void save() {
        System.out.println("MemberRepository save()");
    }
}
