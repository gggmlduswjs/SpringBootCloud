package com.acorn.beanValidSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeanValidSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
