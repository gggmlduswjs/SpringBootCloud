package com.acorn.beanValidSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeanValidSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeanValidSampleApplication.class, args);
	}

}
