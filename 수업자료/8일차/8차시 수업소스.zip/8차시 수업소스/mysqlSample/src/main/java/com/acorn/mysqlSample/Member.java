package com.acorn.mysqlSample;


import lombok.Data;

@Data

public class Member {
    int id;
    String name;
    String email;
    String registration_date;
}
