package com.acorn.mysqlSample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysqlSampleApplication.class, args);
	}

}
