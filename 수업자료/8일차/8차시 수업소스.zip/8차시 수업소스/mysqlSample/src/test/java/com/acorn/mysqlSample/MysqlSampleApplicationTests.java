package com.acorn.mysqlSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
