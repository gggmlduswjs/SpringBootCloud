package com.acorn.validSample;


import lombok.Data;

@Data
public class Order {

    String code;
    String name;
    int qty ;
    int  price ;
    int  amount ;

}
