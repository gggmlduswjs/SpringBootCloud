package com.example.pracConvert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracConvertApplicationTests {

	@Test
	void contextLoads() {
	}

}
