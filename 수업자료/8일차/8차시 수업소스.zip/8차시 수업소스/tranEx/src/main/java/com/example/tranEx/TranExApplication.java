package com.example.tranEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class TranExApplication {

	public static void main(String[] args) {
		SpringApplication.run(TranExApplication.class, args);
	}

}
