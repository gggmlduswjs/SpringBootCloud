package com.example.tranEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TranExApplicationTests {

	@Test
	void contextLoads() {
	}

}
