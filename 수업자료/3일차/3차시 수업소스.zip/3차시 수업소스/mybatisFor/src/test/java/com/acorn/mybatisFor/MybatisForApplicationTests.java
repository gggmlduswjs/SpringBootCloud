package com.acorn.mybatisFor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisForApplicationTests {

	@Test
	void contextLoads() {
	}

}
