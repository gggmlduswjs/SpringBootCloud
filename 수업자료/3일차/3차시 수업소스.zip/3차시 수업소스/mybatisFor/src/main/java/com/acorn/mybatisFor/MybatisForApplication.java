package com.acorn.mybatisFor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MybatisForApplication {

	public static void main(String[] args) {
		SpringApplication.run(MybatisForApplication.class, args);
	}

}
