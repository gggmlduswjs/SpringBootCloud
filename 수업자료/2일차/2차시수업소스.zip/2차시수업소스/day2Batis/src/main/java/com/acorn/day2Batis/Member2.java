package com.acorn.day2Batis;


import lombok.Data;

@Data
public class Member2 {

    String m_id;
    String m_name;
    String m_email;
}
