package com.acorn.cartBatis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartBatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartBatisApplication.class, args);
	}

}
