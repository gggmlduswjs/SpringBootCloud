package com.example.batis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatisApplication.class, args);
	}

}
