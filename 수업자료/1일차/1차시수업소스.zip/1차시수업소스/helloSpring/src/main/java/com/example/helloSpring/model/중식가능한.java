package com.example.helloSpring.model;

interface 중식가능한{
   
    public String  탕수육만들기();
    
}
