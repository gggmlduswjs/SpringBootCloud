package com.example.helloSpring.model;

interface 일식가능한{ 
    public String  초밥만들기(); 
}

