package com.example.helloSpring.model;

interface 한식가능한{
   
    public String  비빔밥만들기();

}