package com.example.helloSpring.model;

public class SampleCook4Main {

	public static void main(String[] args) {
		 
		
		SampleCook4  a= new SampleCook4("손민영");		
		System.out.println( a);

	}

}
