package com.acorn.day01Hello;


import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class User {

    String id;
    String name;
    String tel;
}
