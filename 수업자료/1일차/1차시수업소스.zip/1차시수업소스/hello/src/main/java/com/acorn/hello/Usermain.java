package com.acorn.hello;

public class Usermain {

    public static void main(String[] args) {


        User user = new User();
        user.setId("test");
        user.setPw("0000");


        System.out.println( user);
    }
}
