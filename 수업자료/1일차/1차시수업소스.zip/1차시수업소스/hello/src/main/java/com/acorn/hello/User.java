package com.acorn.hello;


import lombok.Data;



@Data
public class User {
    String id;
    String pw;

}
