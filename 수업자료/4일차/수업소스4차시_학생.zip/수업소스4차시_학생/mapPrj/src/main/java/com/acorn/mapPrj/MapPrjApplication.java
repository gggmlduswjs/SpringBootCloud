package com.acorn.mapPrj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapPrjApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapPrjApplication.class, args);
	}

}
