package com.acorn.mapPrj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapPrjApplicationTests {

	@Test
	void contextLoads() {
	}

}
