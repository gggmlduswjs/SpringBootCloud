package com.acorn.publicData.sample2;

import lombok.Data;

@Data
public class ApiDTO {
	
	String informGrade;
	String informCause;
	String informOverall;
	String informData;
	String imageUrl1;
	String imageUrl2;
	String imageUrl3;
	String imageUrl4;
	String imageUrl5;
	String imageUrl6;
	
}
