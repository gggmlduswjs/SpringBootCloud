package com.acorn.publicData.sample5;

import lombok.Data;

@Data
public class ItemDTO {
	String informData;
	String informGrade;
	String imageUrl1;
	String imageUrl2;
	String imageUrl3;
	String imageUrl4;
	String imageUrl5;
	String imageUrl6;
	String informCause;
}
