package com.acorn.publicData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PublicDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
