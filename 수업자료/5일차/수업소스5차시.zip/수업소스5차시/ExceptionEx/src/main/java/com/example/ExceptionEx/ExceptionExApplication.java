package com.example.ExceptionEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExceptionExApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExceptionExApplication.class, args);
	}

}
