package com.example.ExceptionEx;

public class 예외처리하기3 {

    public static void main(String[] args) {



        // throw  new Exception1("사용자예외");
        //throw new Exception2("사용자 예외  runtimeException");

    }
}
