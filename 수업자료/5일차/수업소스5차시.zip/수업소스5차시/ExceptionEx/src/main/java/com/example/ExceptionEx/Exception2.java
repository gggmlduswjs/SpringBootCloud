package com.example.ExceptionEx;

public class Exception2 extends  RuntimeException{
    public Exception2(String message) {
        super(message);
    }
}
