package com.acorn.ExceptionSample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
