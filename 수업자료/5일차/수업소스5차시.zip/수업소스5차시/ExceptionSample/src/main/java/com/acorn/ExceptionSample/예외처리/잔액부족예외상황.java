package com.acorn.ExceptionSample.예외처리;


public class 잔액부족예외상황  extends  Exception {
    public 잔액부족예외상황() {
        super("잔액부족상황");
    }
}
