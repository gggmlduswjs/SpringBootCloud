package com.acorn.ExceptionSample.예외처리;

public class 대리에게일시키기 {


    public static void main(String[] args) {


        김대리님  a= new 김대리님();
        a.대리가하는일(-10);
    }
}
