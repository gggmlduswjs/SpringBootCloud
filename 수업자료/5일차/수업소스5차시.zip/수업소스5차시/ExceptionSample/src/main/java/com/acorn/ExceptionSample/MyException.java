package com.acorn.ExceptionSample;

public class MyException  extends Exception{
	
	 public MyException() {
		 super("사용자 예외만들기");
	}

}
