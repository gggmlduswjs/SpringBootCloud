package com.example.uploadEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadExApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadExApplication.class, args);
	}

}
