package com.example.restAPI;


import lombok.Data;

@Data
public class Member {
    String  id;
    String  name;
    String email;
}
