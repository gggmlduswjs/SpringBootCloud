package com.example.uploadPrac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadPracApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadPracApplication.class, args);
	}

}
